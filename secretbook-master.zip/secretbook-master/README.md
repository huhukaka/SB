Secretbook
==========

This is a Chrome app for Steganography on Facebook. 

Please note this code was hacked together at the last minute for a university project and will provide you no utility. Seriously. Stop looking now.

Read my research paper on the project (https://github.com/owencm/secretbook/blob/master/secretbook-research-thesis.pdf) and refer to my Javascript JPEG steganography library (https://github.com/owencm/js-steg) for actual resources.
